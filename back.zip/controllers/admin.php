<?php
class AdminController { 
  // Accounts
  public function accounts() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Get the current page, limit, and search query from the request
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : null;
  
    $offset = ($page - 1) * $records_per_page;
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    // Initialize query parameters array
    $query_params = [];
  
    // Count query with search functionality
    $count_query = "SELECT COUNT(*) AS total FROM users";
    if ($search) {
      $count_query .= " WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
      $query_params = [$search, $search, $search];
    }
    $count_stmt = $conn->prepare($count_query);
    if ($search) {
      $count_stmt->bind_param(str_repeat('s', count($query_params)), ...$query_params);
    }
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_records = $count_result->fetch_assoc()['total'];
    $count_stmt->close();
  
    // Main query to fetch filtered users
    $query = "SELECT * FROM users";
    if ($search) {
      $query .= " WHERE (first_name LIKE ? OR last_name LIKE ? OR email LIKE ?)";
    }
    $query .= " LIMIT ?, ?";
  
    $query_params = $search ? array_merge($query_params, [$offset, $records_per_page]) : [$offset, $records_per_page];
    $stmt = $conn->prepare($query);
    $stmt->bind_param($search ? str_repeat('s', count($query_params) - 2) . "ii" : "ii", ...$query_params);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
  
    if ($result->num_rows === 0) {
      echo json_encode(['status' => 'error', 'message' => 'No users found']);
      return;
    }
  
    $users_data = [];
    while ($user = $result->fetch_assoc()) {
      $users_data[] = [
        'user_id' => $user['user_id'],
        'profile' => $user['profile'],
        'student_number' => $user['student_number'],
        'email' => $user['email'],
        'first_name' => ucwords(strtolower($user['first_name'])),
        'last_name' => ucwords(strtolower($user['last_name'])),
        'role' => $user['role'],
        'status' => $user['status'],
        'last_login' => $user['last_login'],
        'created_at' => $user['created_at']
      ];
    }
  
    // Add pagination data to the response
    $response['pagination'] = array(
      'current_page' => $page,
      'records_per_page' => $records_per_page,
      'total_records' => $total_records,
      'total_pages' => ceil($total_records / $records_per_page)
    );
  
    // Return all users' data with pagination info
    $response['status'] = 'success';
    $response['data'] = $users_data;
    echo json_encode($response);
    return;
  }

  public function update_account_status() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();

    $user_id = htmlspecialchars($_GET['uid'] ?? '');
    $status = htmlspecialchars($_GET['status'] ?? '');

    // Create a new instance for API key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'admin'
    if ($api_response['role'] !== 'admin') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }

    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }

    if (empty($status)) {
      $response['status'] = 'error';
      $response['message'] = 'Status cannot be empty';
      echo json_encode($response);
      return;
    }

    $valid_statuses = ['verified', 'accepted', 'declined', 'deactivated'];
    if (!in_array($status, $valid_statuses)) {
      $response['status'] = 'error';
      $response['message'] = 'Invalid status value provided.';
      echo json_encode($response);
      return;
    }

    // Check if the user exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User not found.';
      echo json_encode($response);
      return;
    }

    // Prepare the query to update the account status
    $stmt = $conn->prepare("UPDATE users SET status = ? WHERE user_id = ?");
    $stmt->bind_param("ss", $status, $user_id);
    if ($stmt->execute()){
      $response['status'] = 'success';
      $response['message'] = 'Account status updated successfully';
      echo json_encode($response);
      return;
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Error updating account status: ' . $conn->error;
      echo json_encode($response);
      return;
    }
  }

  public function update_role() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    $user_id = htmlspecialchars($_GET['uid'] ?? '');
    $role = htmlspecialchars($_GET['role'] ?? '');
  
    // Create a new instance for API key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'admin'
    if ($api_response['role'] !== 'admin') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }
  
    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }
  
    if (empty($role)) {
      $response['status'] = 'error';
      $response['message'] = 'Role cannot be empty';
      echo json_encode($response);
      return;
    }
  
    $valid_roles = ['admin', 'student'];
    if (!in_array($role, $valid_roles)) {
      $response['status'] = 'error';
      $response['message'] = 'Invalid role value provided.';
      echo json_encode($response);
      return;
    }
  
    // Check if the user exists
    $stmt = $conn->prepare("SELECT user_id FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
  
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User not found.';
      echo json_encode($response);
      return;
    }
  
    // Prepare the query to update the user role and status
    if ($role === 'admin') {
      // If the role is admin, also set the status to verified
      $stmt = $conn->prepare("UPDATE users SET role = ?, status = 'verified' WHERE user_id = ?");
    } else {
      $stmt = $conn->prepare("UPDATE users SET role = ? WHERE user_id = ?");
    }

    $stmt->bind_param("ss", $role, $user_id);
    if ($stmt->execute()) {
      $response['status'] = 'success';
      $response['message'] = 'User role updated successfully';
      echo json_encode($response);
      return;
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Error updating user role: ' . $conn->error;
      echo json_encode($response);
      return;
    }
  }

  // Subjects
  public function add_subject() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();

    // Create a new instance for API key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'admin'
    if ($api_response['role'] !== 'admin') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }
    
    $pre_requisite_id = bin2hex(random_bytes(16));
    $data = json_decode(file_get_contents("php://input"), true);
    $subject_id = bin2hex(random_bytes(16));
    $curriculum_name = htmlspecialchars(isset($data['curriculum_name']) ? $data['curriculum_name'] : '');
    $subject_code = htmlspecialchars(isset($data['subject_code']) ? $data['subject_code'] : '');
    $subject = htmlspecialchars(isset($data['subject']) ? $data['subject'] : '');
    $lec_unit = htmlspecialchars(isset($data['lec_unit']) ? $data['lec_unit'] : '');
    $lab_unit = htmlspecialchars(isset($data['lab_unit']) ? $data['lab_unit'] : '');
    $lec_hours = htmlspecialchars(isset($data['lec_hours']) ? $data['lec_hours'] : '');
    $lab_hours = htmlspecialchars(isset($data['lab_hours']) ? $data['lab_hours'] : '');
    $year_level = htmlspecialchars(isset($data['year_level']) ? $data['year_level'] : '');
    $year = htmlspecialchars(isset($data['year']) ? $data['year'] : '');
    $semester = htmlspecialchars(isset($data['semester']) ? $data['semester'] : '');
    $created_at = date('Y-m-d H:i:s');
  
    // Validation for required fields
    if (empty($curriculum_name)) {
      $response['status'] = 'error';
      $response['message'] = 'Curriculum name cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($subject_code)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject code cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($subject)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($lec_unit)) {
      $response['status'] = 'error';
      $response['message'] = 'Lec unit cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($lab_unit)) {
      $response['status'] = 'error';
      $response['message'] = 'Lab unit cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($lec_hours)) {
      $response['status'] = 'error';
      $response['message'] = 'Lec hours cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($lab_hours)) {
      $response['status'] = 'error';
      $response['message'] = 'Lab hours cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($year_level)) {
      $response['status'] = 'error';
      $response['message'] = 'Year level cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($year)) {
      $response['status'] = 'error';
      $response['message'] = 'Year cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($semester)) {
      $response['status'] = 'error';
      $response['message'] = 'Semester cannot be empty';
      echo json_encode($response);
      return;
    }

    // Check for duplicate subject within the same year and semester
    $dup_check_sql = "SELECT * FROM subjects WHERE LOWER(subject) = ? AND year = ? AND semester = ?";
    $dup_check_stmt = $conn->prepare($dup_check_sql);
    $dup_check_stmt->bind_param("sss", $subject, $year, $semester);
    $dup_check_stmt->execute();
    $dup_result = $dup_check_stmt->get_result();

    if ($dup_result->num_rows > 0) {
      $response['status'] = 'error';
      $response['message'] = 'Subject already exists for the same year and semester.';
      echo json_encode($response);
      return;
    }
    $dup_check_stmt->close();
  
    // Check if each prerequisite exists in the subjects table
    if (isset($data['pre_requisites']) && is_array($data['pre_requisites'])) {
  
      // If all validations pass, proceed with adding the subject
      $sql = "INSERT INTO subjects (subject_id, curriculum_name, subject_code, subject, lec_unit, lab_unit, lec_hours, lab_hours, pre_requisite_id, year_level, year, semester, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
      $stmt = $conn->prepare($sql);
      $stmt->bind_param(
        "sssssssssssss",
        $subject_id,
        $curriculum_name,
        $subject_code,
        $subject,
        $lec_unit,
        $lab_unit,
        $lec_hours,
        $lab_hours,
        $pre_requisite_id,
        $year_level,
        $year,
        $semester,
        $created_at
      );
  
      if ($stmt->execute()) {
        // Insert prerequisites into the pre_requisites table
        foreach ($data['pre_requisites'] as $pre_req) {
          $pre_req_sql = "INSERT INTO pre_requisites (subject_id, pre_requisite_id) VALUES (?, ?)";
          $pre_req_stmt = $conn->prepare($pre_req_sql);
          $pre_req_stmt->bind_param("ss", $pre_req, $pre_requisite_id);
          $pre_req_stmt->execute();
        }
  
        $response['status'] = 'success';
        $response['message'] = 'Subject added successfully!';
        echo json_encode($response);
        return;
      } else {
        $response['status'] = 'error';
        $response['message'] = 'Failed to add subject.';
        echo json_encode($response);
        return;
      }
  
      $stmt->close();
    }
  }  

  public function subject() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Get parameters from the request
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : null;
    $year = isset($_GET['year']) ? $_GET['year'] : null;
    $semester = isset($_GET['semester']) ? $_GET['semester'] : null;
  
    $offset = ($page - 1) * $records_per_page;
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    // Count query with filters
    $count_query = "SELECT COUNT(*) AS total FROM subjects WHERE 1=1";
    $query_params = [];
    $param_types = "";
  
    if ($search) {
      $count_query .= " AND (subject_code LIKE ? OR subject LIKE ?)";
      $query_params[] = $search;
      $query_params[] = $search;
      $param_types .= "ss";
    }
    if ($year) {
      $count_query .= " AND year = ?";
      $query_params[] = $year;
      $param_types .= "s";
    }
    if ($semester) {
      $count_query .= " AND semester = ?";
      $query_params[] = $semester;
      $param_types .= "s";
    }
  
    $count_stmt = $conn->prepare($count_query);
    if ($param_types) {
      $count_stmt->bind_param($param_types, ...$query_params);
    }
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_records = $count_result->fetch_assoc()['total'];
    $count_stmt->close();
  
    // Main query with filters
    $query = "SELECT subject_id, subject_code, subject, curriculum_name, lec_unit, lab_unit, lec_hours, lab_hours, year_level, year, semester, created_at, pre_requisite_id
              FROM subjects WHERE 1=1";
  
    $query_params = []; // Reset for main query
    $param_types = "";
  
    if ($search) {
      $query .= " AND (subject_code LIKE ? OR subject LIKE ? OR curriculum_name LIKE ? )";
      $query_params[] = $search;
      $query_params[] = $search;
      $query_params[] = $search;
      $param_types .= "sss";
    }
    if ($year) {
      $query .= " AND year = ?";
      $query_params[] = $year;
      $param_types .= "s";
    }
    if ($semester) {
      $query .= " AND semester = ?";
      $query_params[] = $semester;
      $param_types .= "s";
    }
  
    $query .= " ORDER BY id DESC LIMIT ?, ?";
    $query_params[] = $offset;
    $query_params[] = $records_per_page;
    $param_types .= "ii";
  
    $stmt = $conn->prepare($query);
    $stmt->bind_param($param_types, ...$query_params);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result->num_rows === 0) {
      echo json_encode(['status' => 'error', 'message' => 'No subjects found']);
      return;
    }
  
    $subjects_data = [];
    while ($subject = $result->fetch_assoc()) {
      // Fetch prerequisite details as in your original code
      $pre_requisites_query = "SELECT subject_id 
                                FROM pre_requisites
                                WHERE pre_requisite_id = ?";
      $pre_stmt = $conn->prepare($pre_requisites_query);
      $pre_stmt->bind_param("s", $subject['pre_requisite_id']);
      $pre_stmt->execute();
      $pre_result = $pre_stmt->get_result();
      $pre_requisites = [];
  
      while ($pre = $pre_result->fetch_assoc()) {
        $pre_req_id = $pre['subject_id'];
        $subj_details_query = "SELECT subject_id, subject_code, subject 
                                FROM subjects 
                                WHERE subject_id = ?";
        $subj_stmt = $conn->prepare($subj_details_query);
        $subj_stmt->bind_param("s", $pre_req_id);
        $subj_stmt->execute();
        $subj_result = $subj_stmt->get_result();
        $subj_details = $subj_result->fetch_assoc();
        $subj_stmt->close();
  
        if ($subj_details) {
          $pre_requisites[] = [
            'subject_id' => $subj_details['subject_id'],
            'subject_code' => $subj_details['subject_code'],
            'subject' => $subj_details['subject']
          ];
        }
      }
      $pre_stmt->close();
  
      $subjects_data[] = [
        'subject_id' => $subject['subject_id'],
        'subject' => $subject['subject'],
        'subject_code' => $subject['subject_code'],
        'curriculum_name' => $subject['curriculum_name'],
        'lec_unit' => $subject['lec_unit'],
        'lab_unit' => $subject['lab_unit'],
        'lec_hours' => $subject['lec_hours'],
        'lab_hours' => $subject['lab_hours'],
        'year_level' => $subject['year_level'],
        'year' => $subject['year'],
        'semester' => $subject['semester'],
        'created_at' => $subject['created_at'],
        'pre_requisites' => $pre_requisites
      ];
    }
    $stmt->close();
  
    $response['pagination'] = array(
      'current_page' => $page,
      'records_per_page' => $records_per_page,
      'total_records' => $total_records,
      'total_pages' => ceil($total_records / $records_per_page)
    );
  
    $response['status'] = 'success';
    $response['data'] = $subjects_data;
    echo json_encode($response);
    return;
  }

  public function update_subject() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
    
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
    
    // Get input data
    $data = json_decode(file_get_contents("php://input"), true);
    
    $curriculum_name = htmlspecialchars(isset($data['curriculum_name']) ? $data['curriculum_name'] : '');
    $subject_id = htmlspecialchars(isset($_GET['subject_id']) ? $_GET['subject_id'] : '');
    $subject_code = htmlspecialchars(isset($data['subject_code']) ? $data['subject_code'] : '');
    $subject = htmlspecialchars(isset($data['subject']) ? $data['subject'] : '');
    $lec_unit = htmlspecialchars(isset($data['lec_unit']) ? $data['lec_unit'] : '');
    $lab_unit = htmlspecialchars(isset($data['lab_unit']) ? $data['lab_unit'] : '');
    $lec_hours = htmlspecialchars(isset($data['lec_hours']) ? $data['lec_hours'] : '');
    $lab_hours = htmlspecialchars(isset($data['lab_hours']) ? $data['lab_hours'] : '');
    $year_level = htmlspecialchars(isset($data['year_level']) ? $data['year_level'] : '');
    $year = htmlspecialchars(isset($data['year']) ? $data['year'] : '');
    $semester = htmlspecialchars(isset($data['semester']) ? $data['semester'] : '');
    
    // Validation for required fields
    if (empty($curriculum_name)) {
      $response['status'] = 'error';
      $response['message'] = 'Curricular name cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($subject_id)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject ID cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($subject_code)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject code cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($subject)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($year_level)) {
      $response['status'] = 'error';
      $response['message'] = 'Year level cannot be empty';
      echo json_encode($response);
      return;
    }
    if (empty($year)) {
      $response['status'] = 'error';
      $response['message'] = 'Year cannot be empty';
      echo json_encode($response);
      return;
    }
    
    // Check if the subject exists
    $check_query = "SELECT * FROM subjects WHERE subject_id = ?";
    $check_stmt = $conn->prepare($check_query);
    $check_stmt->bind_param("s", $subject_id);
    $check_stmt->execute();
    $check_result = $check_stmt->get_result();
    
    if ($check_result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'Subject not found';
      echo json_encode($response);
      return;
    }
    $check_stmt->close();
    
    // Update the subject
    $update_query = "UPDATE subjects 
                      SET curriculum_name = ?, subject_code = ?, subject = ?, lec_unit = ?, lab_unit = ?, 
                          lec_hours = ?, lab_hours = ?, year_level = ?, year = ?, semester = ?
                      WHERE subject_id = ?";
    $update_stmt = $conn->prepare($update_query);
    $update_stmt->bind_param(
      "sssssssssss",
      $curriculum_name,
      $subject_code,
      $subject,
      $lec_unit,
      $lab_unit,
      $lec_hours,
      $lab_hours,
      $year_level,
      $year,
      $semester,
      $subject_id
    );
    
    if ($update_stmt->execute()) {
      $response['status'] = 'success';
      $response['message'] = 'Subject updated successfully';
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Failed to update subject';
    }
    
    $update_stmt->close();
    
    // Check if there are prerequisites to update
    if (isset($data['pre_requisites']) && is_array($data['pre_requisites'])) {
      // Clear existing prerequisites for the subject
      $delete_pre_req_query = "DELETE FROM pre_requisites WHERE subject_id = ?";
      $delete_stmt = $conn->prepare($delete_pre_req_query);
      $delete_stmt->bind_param("s", $subject_id);
      $delete_stmt->execute();
      $delete_stmt->close();
      
      // Insert updated prerequisites
      foreach ($data['pre_requisites'] as $pre_req) {
        $insert_pre_req_query = "INSERT INTO pre_requisites (subject_id, pre_requisite_id) VALUES (?, ?)";
        $insert_stmt = $conn->prepare($insert_pre_req_query);
        $insert_stmt->bind_param("ss", $subject_id, $pre_req);
        $insert_stmt->execute();
        $insert_stmt->close();
      }
    }
    
    // Return the response
    echo json_encode($response);
  }    

  // Students
  public function students() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Get the current page, limit, and search query from the request
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : null;
  
    $offset = ($page - 1) * $records_per_page;
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    // Initialize query parameters array
    $query_params = [];
  
    // Count query with search functionality
    $count_query = "SELECT COUNT(*) AS total FROM users WHERE role = 'student'";
    if ($search) {
      $count_query .= " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_number LIKE ?)";
      $query_params = [$search, $search, $search, $search];
    }
    $count_stmt = $conn->prepare($count_query);
    if ($search) {
      $count_stmt->bind_param(str_repeat('s', count($query_params)), ...$query_params);
    }
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_records = $count_result->fetch_assoc()['total'];
    $count_stmt->close();
  
    // Main query to fetch filtered users
    $query = "SELECT * FROM users WHERE role = 'student'";
    if ($search) {
      $query .= " AND (first_name LIKE ? OR last_name LIKE ? OR email LIKE ? OR student_number LIKE ?)";
    }
    $query .= " LIMIT ?, ?";
  
    $query_params = $search ? array_merge($query_params, [$offset, $records_per_page]) : [$offset, $records_per_page];
    $stmt = $conn->prepare($query);
    $stmt->bind_param($search ? str_repeat('s', count($query_params) - 2) . "ii" : "ii", ...$query_params);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
  
    if ($result->num_rows === 0) {
      echo json_encode(['status' => 'error', 'message' => 'No users found']);
      return;
    }
  
    $users_data = [];
    while ($user = $result->fetch_assoc()) {
      $users_data[] = [
        'user_id' => $user['user_id'],
        'profile' => $user['profile'],
        'student_number' => $user['student_number'],
        'email' => $user['email'],
        'first_name' => ucwords(strtolower($user['first_name'])),
        'last_name' => ucwords(strtolower($user['last_name'])),
        'role' => $user['role'],
        'status' => $user['status'],
        'last_login' => $user['last_login'],
        'created_at' => $user['created_at']
      ];
    }
  
    // Add pagination data to the response
    $response['pagination'] = array(
      'current_page' => $page,
      'records_per_page' => $records_per_page,
      'total_records' => $total_records,
      'total_pages' => ceil($total_records / $records_per_page)
    );
  
    // Return all users' data with pagination info
    $response['status'] = 'success';
    $response['data'] = $users_data;
    echo json_encode($response);
    return;
  }  

  public function assign_subject() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
    
    // Create a new instance for API key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'admin'
    if ($api_response['role'] !== 'admin') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }
    
    $pre_requisite_id = bin2hex(random_bytes(16));
    $assign_id = bin2hex(random_bytes(16));
    $user_id = htmlspecialchars(isset($_GET['user_id']) ? $_GET['user_id'] : '');
    $subject_id = htmlspecialchars(isset($_GET['subject_id']) ? $_GET['subject_id'] : '');
    $credits = isset($_GET['credits']) ? htmlspecialchars($_GET['credits']) : null; // Optional, can be null
    $is_enrolled = isset($_GET['is_enrolled']) ? filter_var($_GET['is_enrolled'], FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE) : null; // Optional, can be null
    $created_at = date('Y-m-d H:i:s');
    
    // Validate user_id
    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }
    
    // Check if user_id exists in the users table
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $stmt->bind_result($user_exists);
    $stmt->fetch();
    $stmt->close();
    
    if ($user_exists === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User ID does not exist';
      echo json_encode($response);
      return;
    }
    
    // Validate subject_id
    if (empty($subject_id)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject cannot be empty';
      echo json_encode($response);
      return;
    }
    
    // Check if subject_id exists in the subjects table
    $stmt = $conn->prepare("SELECT COUNT(*) FROM subjects WHERE subject_id = ?");
    $stmt->bind_param("s", $subject_id);
    $stmt->execute();
    $stmt->bind_result($subject_exists);
    $stmt->fetch();
    $stmt->close();
    
    if ($subject_exists === 0) {
      $response['status'] = 'error';
      $response['message'] = 'Subject ID does not exist';
      echo json_encode($response);
      return;
    }
    
    // Validate credits if provided
    if (!empty($credits)) {
      if (!is_numeric($credits) || $credits < 1.0 || $credits > 5.0 || fmod($credits * 20, 1) != 0) {
        $response['status'] = 'error';
        $response['message'] = 'Credits must be a decimal value between 1.0 and 5.0, in increments of 0.05';
        echo json_encode($response);
        return;
      }
    }
    
    // Set default values if not provided
    if ($is_enrolled === null) {
      $is_enrolled = 0; // Default to not enrolled if not provided
    }
    if ($credits === null) {
      $credits = 3.0; // Default credits if not provided
    }
    
    // Check if enrollment record exists
    $stmt = $conn->prepare("SELECT COUNT(*) FROM enrollment WHERE user_id = ? AND subject_id = ?");
    $stmt->bind_param("ss", $user_id, $subject_id);
    $stmt->execute();
    $stmt->bind_result($enrollment_exists);
    $stmt->fetch();
    $stmt->close();
    
    if ($enrollment_exists > 0) {
      // Prepare update query based on which fields need updating
      $update_sql = "UPDATE enrollment SET ";
      $update_params = [];
      $types = '';  // Track parameter types for bind_param
      
      // If credits are provided, update it
      if ($credits !== null) {
        $update_sql .= "credits = ?, ";
        $update_params[] = $credits;
        $types .= 'd';  // 'd' for decimal type
      }
    
      // If is_enrolled is provided, update it
      if ($is_enrolled !== null) {
        $update_sql .= "is_enrolled = ?, ";
        $update_params[] = $is_enrolled;
        $types .= 'i';  // 'i' for integer type
      }
    
      // Remove trailing comma and space
      $update_sql = rtrim($update_sql, ', ') . " WHERE user_id = ? AND subject_id = ?";
      $update_params[] = $user_id;
      $update_params[] = $subject_id;
      $types .= 'ss';  // 'ss' for string types (user_id, subject_id)
    
      // Prepare and execute the update statement
      $stmt = $conn->prepare($update_sql);
      $stmt->bind_param($types, ...$update_params);
      
      if ($stmt->execute()) {
        $response['status'] = 'success';
        $response['message'] = 'Subject assignment updated successfully';
        echo json_encode($response);
        return;
      } else {
        $response['status'] = 'error';
        $response['message'] = 'Failed to update subject assignment';
        echo json_encode($response);
        return;
      }
    } else {
      // Insert new record
      $stmt = $conn->prepare("INSERT INTO enrollment (assign_id, user_id, subject_id, credits, is_enrolled, created_at) VALUES (?, ?, ?, ?, ?, ?)");
      $stmt->bind_param("ssssss", $assign_id, $user_id, $subject_id, $credits, $is_enrolled, $created_at);
      
      if ($stmt->execute()) {
        $response['status'] = 'success';
        $response['message'] = 'Subject assigned successfully';
        echo json_encode($response);
        return;
      } else {
        $response['status'] = 'error';
        $response['message'] = 'Failed to assign subject';
        echo json_encode($response);
        return;
      }
    }
    
    $stmt->close();
  }  

  public function assign() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Get parameters from the request
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;
    $search = isset($_GET['search']) ? "%" . $_GET['search'] . "%" : null;
    $user_id = isset($_GET['uid']) ? $_GET['uid'] : null;
    $year = isset($_GET['year']) ? $_GET['year'] : null;
    $semester = isset($_GET['semester']) ? $_GET['semester'] : null;
  
    $offset = ($page - 1) * $records_per_page;
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }
  
    // Check if user_id exists in the users table
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $stmt->bind_result($user_exists);
    $stmt->fetch();
    $stmt->close();
  
    if ($user_exists === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User ID does not exist';
      echo json_encode($response);
      return;
    }
  
    // Build the query with optional filters
    $query_params = [$user_id];
    $count_query = "
    SELECT COUNT(*) AS total 
    FROM subjects s
    INNER JOIN enrollment e ON s.subject_id = e.subject_id 
    WHERE e.user_id = ? AND s.year = ? AND s.semester = ?
    ";

    $query_params = [$user_id, $year, $semester];

    if ($search) {
    $count_query .= " AND (s.subject_code LIKE ? OR s.subject LIKE ?)";
    $query_params[] = $search;
    $query_params[] = $search;
    }

    $count_stmt = $conn->prepare($count_query);
    $param_types = "sss" . ($search ? "ss" : "");
    $count_stmt->bind_param($param_types, ...$query_params);
    $count_stmt->execute();
    $count_result = $count_stmt->get_result();
    $total_records = $count_result->fetch_assoc()['total'];
    $count_stmt->close();

    // Main query to fetch subjects and enrollment data for the user
    $query = "
    SELECT s.subject_id, s.subject_code, s.subject, s.lec_unit, s.lab_unit, 
          s.lec_hours, s.lab_hours, s.year, s.semester, s.created_at, 
          e.credits, e.is_enrolled
    FROM subjects s
    INNER JOIN enrollment e ON s.subject_id = e.subject_id 
    WHERE e.user_id = ? AND s.year = ? AND s.semester = ?
    ";

    $query_params = [$user_id, $year, $semester];

    if ($search) {
    $query .= " AND (s.subject_code LIKE ? OR s.subject LIKE ?)";
    $query_params[] = $search;
    $query_params[] = $search;
    }
    $query .= " LIMIT ?, ?";
    $query_params[] = $offset;
    $query_params[] = $records_per_page;

    $stmt = $conn->prepare($query);
    $param_types = "sss" . ($search ? "ss" : "") . "ii";
    $stmt->bind_param($param_types, ...$query_params);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'No data found';
      echo json_encode($response);
      return;
    }
  
    $subjects_data = [];
    while ($subject = $result->fetch_assoc()) {
      $subjects_data[] = [
        'subject_id' => $subject['subject_id'],
        'subject_code' => $subject['subject_code'],
        'subject' => $subject['subject'],
        'lec_unit' => $subject['lec_unit'],
        'lab_unit' => $subject['lab_unit'],
        'lec_hours' => $subject['lec_hours'],
        'lab_hours' => $subject['lab_hours'],
        'year' => $subject['year'],
        'semester' => $subject['semester'],
        'created_at' => $subject['created_at'],
        'credits' => $subject['credits'],
        'is_enrolled' => $subject['is_enrolled']
      ];
    }
    $stmt->close();
  
    // Add pagination data to the response
    $response['pagination'] = array(
      'current_page' => $page,
      'records_per_page' => $records_per_page,
      'total_records' => $total_records,
      'total_pages' => ceil($total_records / $records_per_page)
    );
  
    // Return subjects data with pagination info
    $response['status'] = 'success';
    $response['data'] = $subjects_data;
    echo json_encode($response);
    return;
  }  

  public function insert_assign_subject() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Create a new instance for API key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    // Check if the user's role is 'admin'
    if ($api_response['role'] !== 'admin') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }
  
    // Retrieve the user_id from the query string
    $user_id = htmlspecialchars(isset($_GET['user_id']) ? $_GET['user_id'] : ''); 
    $assign_id = bin2hex(random_bytes(16));
    $created_at = date('Y-m-d H:i:s');
  
    // Validate user_id
    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }
  
    // Check if user_id exists in the users table
    $stmt = $conn->prepare("SELECT COUNT(*) FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $stmt->bind_result($user_exists);
    $stmt->fetch();
    $stmt->close();
  
    if ($user_exists === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User ID does not exist';
      echo json_encode($response);
      return;
    }
  
    // Read the raw POST data
    $inputData = json_decode(file_get_contents('php://input'), true);
    
    // Validate subject_ids (ensure it's an array and not empty)
    $subject_ids = isset($inputData['subject_ids']) ? $inputData['subject_ids'] : [];
  
    if (empty($subject_ids) || !is_array($subject_ids)) {
      $response['status'] = 'error';
      $response['message'] = 'Subject IDs cannot be empty or invalid';
      echo json_encode($response);
      return;
    }
  
    // Validate that all subject IDs exist in the subjects table
    $placeholders = str_repeat('?,', count($subject_ids) - 1) . '?';
    $stmt = $conn->prepare("SELECT subject_id, year, semester, subject_code, curriculum_name FROM subjects WHERE subject_id IN ($placeholders)");
    $stmt->bind_param(str_repeat('s', count($subject_ids)), ...$subject_ids);
    $stmt->execute();
    $result = $stmt->get_result();
    $valid_subject_ids = [];
    $subject_details = [];
  
    while ($row = $result->fetch_assoc()) {
      $valid_subject_ids[] = $row['subject_id'];
      $subject_details[$row['subject_id']] = $row;
    }
    $stmt->close();
  
    // Check if all subjects are valid
    if (count($valid_subject_ids) !== count($subject_ids)) {
      $response['status'] = 'error';
      $response['message'] = 'One or more subject IDs are invalid';
      echo json_encode($response);
      return;
    }
    
    // Prepare a query to validate subject assignments
    $stmt = $conn->prepare("SELECT COUNT(*) 
                            FROM enrollment e
                            JOIN subjects s ON e.subject_id = s.subject_id
                            WHERE e.user_id = ? 
                            AND s.subject_id = ? 
                            AND s.year = ? 
                            AND s.semester = ? 
                            AND s.subject_code = ? 
                            AND s.curriculum_name = ?");

    foreach ($subject_ids as $subject_id) {
      // Ensure the subject_id has valid details
      if (!isset($subject_details[$subject_id])) {
        echo json_encode([
          'status' => 'error',
          'message' => "Details for Subject ID $subject_id not found."
        ]);
        return;
      }

      $details = $subject_details[$subject_id];

      // Bind parameters and check for existing assignments
      $stmt->bind_param(
        "ssssss",
        $user_id,
        $details['subject_id'],
        $details['year'],
        $details['semester'],
        $details['subject_code'],
        $details['curriculum_name']
      );
      $stmt->execute();
      $stmt->bind_result($existing_count);
      $stmt->fetch();

      if ($existing_count > 0) {
        $subject_code = $details['subject_code'];
        echo json_encode([
          'status' => 'error',
          'message' => "Subject with code $subject_code is already assigned to the student."
        ]);
        return;
      }
    }
    $stmt->close();
  
    // Insert new subject assignments into the enrollment table
    $stmt = $conn->prepare("INSERT INTO enrollment (assign_id, user_id, subject_id, created_at) VALUES (?, ?, ?, ?)");
  
    foreach ($subject_ids as $subject_id) {
      // For each subject_id, create a new enrollment record
      $stmt->bind_param("ssss", $assign_id, $user_id, $subject_id, $created_at);
      if (!$stmt->execute()) {
        $response['status'] = 'error';
        $response['message'] = 'Failed to assign subject';
        echo json_encode($response);
        return;
      }
    }
  
    $stmt->close();
  
    // Return success response after all subjects are assigned
    $response['status'] = 'success';
    $response['message'] = 'Subjects assigned successfully';
    echo json_encode($response);
  }      
}

?>