<?php

class StudentController{
  public function update_user_by_id(){
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();

    $data = json_decode(file_get_contents("php://input"), true);
    $user_id = htmlspecialchars(isset($data['user_id']) ? $data['user_id'] : '');
    $student_number = htmlspecialchars(isset($data['student_number']) ? $data['student_number'] : '');

    // Create a new instance for api key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'student'
    if ($api_response['role'] !== 'student') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }

    if(empty($user_id)){
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }

    if(empty($student_number)){
      $response['status'] = 'error';
      $response['message'] = 'Student number cannot be empty';
      echo json_encode($response);
      return;
    }

    $stmt = $conn->prepare("UPDATE users SET student_number = ? WHERE user_id = ?");
    $stmt->bind_param("ss", $student_number, $user_id);

    if ($stmt->execute()){
      $response['status'] = 'success';
      $response['message'] = 'Student number updated successfully';
      echo json_encode($response);
      return;
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Error updating student number: ' . $conn->error;
      echo json_encode($response);
      return;
    }

    $stmt->close();
  }
  
  public function get_user_by_id(){
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();

    $user_id = htmlspecialchars(isset($_GET['uid']) ? $_GET['uid'] : '');

    // Create a new instance for api key validation
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Check if the user's role is 'student'
    if ($api_response['role'] !== 'student') {
      echo json_encode([
        'status' => 'error', 
        'message' => 'Unauthorized access'
      ]);
      return;
    }

    if(empty($user_id)){
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }

    // Check if user do not exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    // Check if the user exists
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'This user do not exist';
      echo json_encode($response);
      return;
    }

    $user = $result->fetch_assoc();

    $response['status'] = 'success';
    $response['user'] = [
      'profile' => $user['profile'],
      'student_number' => $user['student_number'],
      'email' => $user['email'],  
      'first_name' => ucwords(strtolower($user['first_name'])),
      'last_name' => ucwords(strtolower($user['last_name'])),
      'role' => $user['role'],
      'status' => $user['status']
    ];
    echo json_encode($response);
    return;
  }

  public function verify_user(){
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
    $mail = new SendEmail();

    $email = htmlspecialchars(isset($_GET['email']) ? $_GET['email'] : '');
    $token = htmlspecialchars(isset($_GET['token']) ? $_GET['token'] : '');

    if (empty($token)) {
      $response['status'] = 'error';
      $response['message'] = 'Token cannot be empty';
      echo json_encode($response);
      return;
    }

    if (empty($email)) {
      $response['status'] = 'error';
      $response['message'] = 'Email cannot be empty';
      echo json_encode($response);
      return;
    }

    // Check if email exists
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND user_id = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();

    // Check if the user exists
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'This user does not exist';
      echo json_encode($response);
      return;
    }

    $user = $result->fetch_assoc();

    // Check if the user is already verified
    if ($user['status'] === 'verified') {
      $response['status'] = 'success';
      $response['message'] = 'User is already verified';
      echo json_encode($response);
      return;
    }

    // Send email notification to user
    $first_name = $user['first_name']; 
    $last_name = $user['last_name'];  
    $verification_link = "http://localhost/capstone2/api/student/verify?email=" . urlencode($email) . "&token=" . urlencode($token);
  
    $senderName = 'UPHSD Course Monitoring and Curriculum Tracking';
    $senderEmail = 'razonmarknicholas.cdlb@gmail.com';
    $subject = 'Account Verification';
    $body = "
      <h1>Verify Your Account</h1>
      <p>Hello $first_name $last_name, Please click the link below to verify your account:<br><a href='$verification_link'>Verify My Account</a><br><br>Thank you!</p>
    ";
  
    // Send the email using SendEmail class
    $emailResponse = $mail->sendMail($senderName, $senderEmail, $email, $subject, $body);
  
    if ($emailResponse) {
      $response['status'] = 'success';
      $response['message'] = 'Verification email sent successfully';
      echo json_encode($response);
      return;
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Failed to send verification email';
      echo json_encode($response);
      return;
    }
  }

  public function update_user_status(){
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    $email = htmlspecialchars(isset($_GET['email']) ? $_GET['email'] : '');
    $token = htmlspecialchars(isset($_GET['token']) ? $_GET['token'] : '');
  
    // Check if the token and email are provided
    if (empty($token)) {
      $response['status'] = 'error';
      $response['message'] = 'Token cannot be empty';
      echo json_encode($response);
      return;
    }
  
    if (empty($email)) {
      $response['status'] = 'error';
      $response['message'] = 'Email cannot be empty';
      echo json_encode($response);
      return;
    }
  
    // Verify if the user exists with the given email and token
    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ? AND user_id = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'Invalid token or user does not exist';
      echo json_encode($response);
      return;
    }
  
    $user = $result->fetch_assoc();
  
    // Check if the user is already verified
    if ($user['status'] === 'verified') {
      $response['status'] = 'success';
      $response['message'] = 'User is already verified';
      echo json_encode($response);
      return;
    }
  
    // Update user status to 'verified'
    $stmt = $conn->prepare("UPDATE users SET status = 'verified' WHERE email = ? AND user_id = ?");
    $stmt->bind_param("ss", $email, $token);
  
    if ($stmt->execute()) {
      $response['status'] = 'success';
      $response['message'] = 'User verified successfully';
      header('location: http://localhost:3000/student/account');
      echo json_encode($response);
      return;
    } else {
      $response['status'] = 'error';
      $response['message'] = 'Failed to update user status';
      echo json_encode($response);
      return;
    }

    $stmt->close();
  }  

  public function get_enrollment_by_user_id() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
    
    // Retrieve and sanitize input
    $user_id = htmlspecialchars(isset($_GET['user_id']) ? $_GET['user_id'] : '');
    
    // Validate API key
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
    
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
    
    // Restrict access to authorized roles
    if ($api_response['role'] !== 'student') {
      echo json_encode([
        'status' => 'error',
        'message' => 'Unauthorized access'
      ]);
      return;
    }
    
    // Validate user ID
    if (empty($user_id)) {
      $response['status'] = 'error';
      $response['message'] = 'User ID cannot be empty';
      echo json_encode($response);
      return;
    }
    
    // Fetch user details
    $stmt = $conn->prepare("SELECT student_number, first_name, last_name FROM users WHERE user_id = ?");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $user_result = $stmt->get_result();
    $stmt->close();
    
    if ($user_result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'User does not exist';
      echo json_encode($response);
      return;
    }
    
    $user_data = $user_result->fetch_assoc();
    $student_number = $user_data['student_number'];
    $first_name = $user_data['first_name'];
    $last_name = $user_data['last_name'];
    
    // Query the enrollment table with subjects details
    $stmt = $conn->prepare("
      SELECT e.assign_id, e.user_id, e.subject_id, e.credits, e.is_enrolled, 
             s.year, s.semester, s.subject_code, s.subject, s.lec_hours, s.lab_hours, s.lec_unit, s.lab_unit
      FROM enrollment e
      JOIN subjects s ON e.subject_id = s.subject_id
      WHERE e.user_id = ? ORDER BY s.year ASC");
    $stmt->bind_param("s", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $stmt->close();
    
    // Check if records exist
    if ($result->num_rows === 0) {
      $response['status'] = 'error';
      $response['message'] = 'No enrollment records found for this user';
      echo json_encode($response);
      return;
    }
  
    // Initialize totals and GWA calculation variables
    $total_lec_unit_taken = 0;
    $total_lec_unit_required = 0;
    $total_grade_points = 0;
    $total_credits = 0;

    // Define grade points for specific grades (you can customize this based on your grading system)
    $grade_points = [
      'passed' => 1.0,  
      'failed' => 5.0  
    ];

    // Organize data by academic year, year, and semester
    $enrollment_data = [];
    $academic_years = [];

    while ($row = $result->fetch_assoc()) {
      // Add to totals
      $total_lec_unit_required += $row['lec_unit']; // Add to total required units regardless of enrollment
      
      if ($row['is_enrolled'] > 0) {
        // Only add to total units taken for enrolled subjects
        $total_lec_unit_taken += $row['lec_unit'];
      }
        
      // Determine the status based on is_enrolled and credits
      if ($row['is_enrolled'] == 0 && $row['credits'] == 0) {
        $status = 'unenrolled';
      } elseif ($row['is_enrolled'] > 0 && $row['credits'] == 0) {
        $status = 'enrolled';
      } elseif ($row['is_enrolled'] > 0 && $row['credits'] >= 1.0 && $row['credits'] <= 3.0) {
        $status = 'passed';
      } elseif ($row['is_enrolled'] > 0 && $row['credits'] > 3.0) {
        $status = 'failed';
      } else {
        $status = 'unenrolled'; // Default to unenrolled in case of unexpected values
      }
        
      // Calculate grade points based on status
      if ($status === 'passed' || $status === 'failed') {
        // Calculate grade points for passed or failed subjects
        $grade_points_earned = $row['credits'] * $grade_points[$status];
        $total_grade_points += $grade_points_earned;
        $total_credits += $row['credits'];
      }

      // Initialize year and semester arrays if they don't exist
      if (!isset($enrollment_data[$row['year']])) {
        $enrollment_data[$row['year']] = [];
      }
      if (!isset($enrollment_data[$row['year']][$row['semester']])) {
        $enrollment_data[$row['year']][$row['semester']] = [];
      }
      
      // Add the enrollment record to the correct year and semester with status
      $enrollment_data[$row['year']][$row['semester']][] = [
        'assign_id' => $row['assign_id'],
        'user_id' => $row['user_id'],
        'subject_id' => $row['subject_id'],
        'subject_code' => $row['subject_code'],
        'subject' => $row['subject'],
        'lec_hours' => $row['lec_hours'],
        'lab_hours' => $row['lab_hours'],
        'lec_unit' => $row['lec_unit'],
        'lab_unit' => $row['lab_unit'],
        'credits' => $row['credits'],
        'is_enrolled' => $row['is_enrolled'],
        'status' => $status // Add the status field
      ];
    
      // Add academic years to the list
      $academic_years[] = $row['year'];
    }

    // Calculate GWA
    $gwa = ($total_credits > 0) ? round($total_grade_points / $total_credits, 2) : 0;

    // Get the last two unique academic years and format them as 'YYYY-YYYY'
    $unique_years = array_unique($academic_years);
    sort($unique_years);
    $latest_year = end($unique_years);
    $previous_year = prev($unique_years);

    $academic_year_range = [
      'year' => $latest_year
    ];

    $remaining_lec_units = $total_lec_unit_required - $total_lec_unit_taken;

    // Return success response
    $response['status'] = 'success';
    $response['user'] = [
      'student_number' => $student_number,
      'first_name' => $first_name,
      'last_name' => $last_name
    ];
    $response['totals'] = [
      'lec_unit_taken' => $total_lec_unit_taken,
      'lec_unit_required' => $total_lec_unit_required,
      'remaining_lec_units' => $remaining_lec_units,
      'academic_year' => $academic_year_range,
      'gwa' => $gwa
    ];
    $response['enrollment'] = $enrollment_data;
    echo json_encode($response);
    return;
  }

  public function curriculum() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Get the year from the request
    $year = isset($_GET['year']) ? $_GET['year'] : null;
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'student') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    // Main query with a filter for the year and its following year
    $query = "SELECT subject_id, curriculum_name, subject_code, subject, lec_unit, lab_unit, lec_hours, lab_hours, year_level, year, semester, created_at, pre_requisite_id
              FROM subjects WHERE year = ? OR year = ?";
    $next_year = $year + 1;
  
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ss", $year, $next_year);
    $stmt->execute();
    $result = $stmt->get_result();
  
    if ($result->num_rows === 0) {
      echo json_encode(['status' => 'error', 'message' => 'No subjects found']);
      return;
    }
  
    $subjects_data = [];
    while ($subject = $result->fetch_assoc()) {
      // Fetch prerequisite details
      $pre_requisites_query = "SELECT subject_id 
                                FROM pre_requisites
                                WHERE pre_requisite_id = ?";
      $pre_stmt = $conn->prepare($pre_requisites_query);
      $pre_stmt->bind_param("s", $subject['pre_requisite_id']);
      $pre_stmt->execute();
      $pre_result = $pre_stmt->get_result();
      $pre_requisites = [];
  
      while ($pre = $pre_result->fetch_assoc()) {
        $pre_req_id = $pre['subject_id'];
        $subj_details_query = "SELECT subject_id, subject_code, subject 
                                FROM subjects 
                                WHERE subject_id = ?";
        $subj_stmt = $conn->prepare($subj_details_query);
        $subj_stmt->bind_param("s", $pre_req_id);
        $subj_stmt->execute();
        $subj_result = $subj_stmt->get_result();
        $subj_details = $subj_result->fetch_assoc();
        $subj_stmt->close();
  
        if ($subj_details) {
          $pre_requisites[] = [
            'subject_id' => $subj_details['subject_id'],
            'subject_code' => $subj_details['subject_code'],
            'subject' => $subj_details['subject']
          ];
        }
      }
      $pre_stmt->close();
  
      $subjects_data[] = [
        'curriculum_name' => $subject['curriculum_name'],
        'subject_id' => $subject['subject_id'],
        'subject_code' => $subject['subject_code'],
        'subject' => $subject['subject'],
        'lec_unit' => $subject['lec_unit'],
        'lab_unit' => $subject['lab_unit'],
        'lec_hours' => $subject['lec_hours'],
        'lab_hours' => $subject['lab_hours'],
        'year_level' => $subject['year_level'],
        'year' => $subject['year'],
        'semester' => $subject['semester'],
        'created_at' => $subject['created_at'],
        'pre_requisites' => $pre_requisites
      ];
    }
    $stmt->close();
  
    $response['status'] = 'success';
    $response['data'] = $subjects_data;
    echo json_encode($response);
    return;
  }  
}
?>