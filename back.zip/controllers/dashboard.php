<?php
class DashboardController {
  public function totals() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();

    // Get the current page and limit
    $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
    $records_per_page = isset($_GET['limit']) ? (int)$_GET['limit'] : 50;

    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();

    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }

    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }

    // Calculate totals
    $totals = [
      'total_enrolleed' => 0,
      'total_passed' => 0,
      'total_failed' => 0,
      'total_admins' => 0,
      'total_students' => 0
    ];

    // Total enrollees
    $result = $conn->query("SELECT COUNT(*) AS total FROM enrollment");
    $totals['total_enrolleed'] = $result->fetch_assoc()['total'];

    // Total passed
    $result = $conn->query("SELECT COUNT(*) AS total FROM enrollment WHERE credits >= 1.0 AND credits <= 3.0");
    $totals['total_passed'] = $result->fetch_assoc()['total'];

    // Total failed
    $result = $conn->query("SELECT COUNT(*) AS total FROM enrollment WHERE credits > 3.0");
    $totals['total_failed'] = $result->fetch_assoc()['total'];

    // Total admins
    $result = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'admin'");
    $totals['total_admins'] = $result->fetch_assoc()['total'];

    // Total students
    $result = $conn->query("SELECT COUNT(*) AS total FROM users WHERE role = 'student'");
    $totals['total_students'] = $result->fetch_assoc()['total'];

    // Add pagination data to the response
    $response['pagination'] = array(
      'current_page' => $page,
      'records_per_page' => $records_per_page,
      'total_records' => 1,
      'total_pages' => 1
    );

    // Return totals in response
    $response['status'] = 'success';
    $response['data'] = [$totals];

    echo json_encode($response);
    return;
  }
  
  public function dashboard() {
    global $conn;
    date_default_timezone_set('Asia/Manila');
    $response = array();
  
    // Validate API key and role
    $api_key = new SecurityKey($conn);
    $api_response = $api_key->validateBearerToken();
  
    if ($api_response['status'] === 'error') {
      echo json_encode($api_response);
      return;
    }
  
    if ($api_response['role'] !== 'admin') {
      echo json_encode(['status' => 'error', 'message' => 'Unauthorized access']);
      return;
    }
  
    // Query to get monthly enrollees count
    $query = "
      SELECT 
        MONTH(created_at) AS month, 
        COUNT(*) AS total 
      FROM enrollment 
      WHERE YEAR(created_at) = YEAR(CURRENT_DATE)
      GROUP BY MONTH(created_at)
    ";
  
    $result = $conn->query($query);
  
    // Initialize monthly enrollees with zero
    $monthly_enrollees = [
      'jan' => 0,
      'feb' => 0,
      'mar' => 0,
      'apr' => 0,
      'may' => 0,
      'jun' => 0,
      'jul' => 0,
      'aug' => 0,
      'sep' => 0,
      'oct' => 0,
      'nov' => 0,
      'dec' => 0,
    ];
  
    // Populate the monthly enrollees from the query result
    while ($row = $result->fetch_assoc()) {
      $month_index = (int)$row['month'];
      $month_key = strtolower(date('M', mktime(0, 0, 0, $month_index, 1)));
      $monthly_enrollees[$month_key] = (int)$row['total'];
    }
  
    // Return the response
    $response['status'] = 'success';
    $response['data'] = $monthly_enrollees;
  
    echo json_encode($response);
    return;
  }  
}
?>
