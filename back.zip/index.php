<?php
require 'config.php';
require 'router.php';
require 'key.php';
require 'email.php';

// Controllers
require 'controllers/auth.php';
require 'controllers/admin.php';
require 'controllers/dashboard.php';
require 'controllers/student.php';
// require 'vendor/autoload.php';

// Initialize Router
$router = new Router();

// Auth
$router->post('/api/auth/register', 'AuthController@register');
$router->post('/api/auth/login', 'AuthController@login');
$router->post('/api/auth/forgot-password', 'AuthController@forgot_password');
$router->post('/api/auth/reset-password', 'AuthController@reset_password');
$router->get('/api/auth/microsoft', 'AuthController@microsoft_auth');

// Student
$router->get('/api/student/user', 'StudentController@get_user_by_id');
$router->put('/api/student/user', 'StudentController@update_user_by_id');
$router->get('/api/student/verification', 'StudentController@verify_user');
$router->get('/api/student/verify', 'StudentController@update_user_status');
$router->get('/api/student/enrollment', 'StudentController@get_enrollment_by_user_id');
$router->get('/api/student/curriculum', 'StudentController@curriculum');

// Admin
$router->get('/api/admin/accounts', 'AdminController@accounts');
$router->put('/api/admin/accounts', 'AdminController@update_account_status');
$router->post('/api/admin/subject', 'AdminController@add_subject');
$router->get('/api/admin/subject', 'AdminController@subject');
$router->put('/api/admin/subject', 'AdminController@update_subject');
$router->get('/api/admin/students', 'AdminController@students');
$router->post('/api/admin/assign', 'AdminController@insert_assign_subject');
$router->put('/api/admin/assign', 'AdminController@assign_subject');
$router->put('/api/admin/role', 'AdminController@update_role');
$router->get('/api/admin/assign', 'AdminController@assign');

// Dashboard
$router->get('/api/admin/totals', 'DashboardController@totals');
$router->get('/api/admin/dashboard', 'DashboardController@dashboard');

// Dispatch the request
$router->dispatch();
?>